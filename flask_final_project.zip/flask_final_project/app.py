import sqlite3
from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)
DATABASE = 'database.db'

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

@app.teardown_appcontext
def close_db_connection(exception=None):
    conn = get_db_connection()
    if conn is not None:
        conn.close()

def create_table():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS reservations (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            email TEXT NOT NULL,
            check_in_date DATE NOT NULL,
            check_out_date DATE NOT NULL,
            num_guests INTEGER NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

def insert_reservation(name, email, check_in_date, check_out_date, num_guests):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO reservations (name, email, check_in_date, check_out_date, num_guests) VALUES (?, ?, ?, ?, ?)",
                   (name, email, check_in_date, check_out_date, num_guests))
    reservation_id = cursor.lastrowid 
    conn.commit()
    conn.close()
    return reservation_id

def get_reservations():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM reservations")
    reservations = cursor.fetchall()
    conn.close()
    return reservations

# Create the reservations table when the application starts
create_table()

@app.route('/')
def welcome():
    return render_template('welcome.html')

@app.route('/reservation', methods=['GET', 'POST'])
def reservation():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        check_in_date = request.form['check_in_date']
        check_out_date = request.form['check_out_date']
        num_guests = request.form['num_guests']
        reservation_id = insert_reservation(name, email, check_in_date, check_out_date, num_guests)
        return redirect(url_for('confirmation', reservation_id=reservation_id))  
    return render_template('reservation.html')

@app.route('/confirmation')
def confirmation():
    reservation_id = request.args.get('reservation_id')
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM reservations WHERE id=?", (reservation_id,))
    reservation = cursor.fetchone()
    conn.close()
    return render_template('confirmation.html', reservation=reservation)

@app.route('/reservation_list')
def reservation_list():
    reservations = get_reservations()
    return render_template('reservation_list.html', reservations=reservations)

if __name__ == '__main__':
    app.run(debug=True)
